package task1;

public class List {
	private Node head;
	public List() {
		this.head = null;
	}
	//Constructor: Initializes an empty linked list
	public boolean isEmpty() {
		return this.head == null;
	}
	
	//Inserts a new node with value x at the specified index
	public Node insertNode(int index, double x) {
		if(index < 0)
			return null;
		int currIndex = 1;
		Node currNode = this.head;
		//Traverse to the node before the target index (or end of list)
		while(currNode != null && index > currIndex) {
			currNode = currNode.getNext();
			currIndex ++;
		}
		//If index exceeds list length (and index > 0), insertion fails
		if(index > 0 && currNode == null)
			return null;
		
		Node newNode = new Node(x);
		//insert at head
		if(index == 0) {
			newNode.setNext(this.head);
			this.head = newNode;
		}
		//insert at middle or end
		else {
			newNode.setNext(currNode.getNext());
			currNode.setNext(newNode);
		}
		return newNode;
	}
	
	//Finds the first node with the specified value x
	public Node findNode(double x) {
		//Traverse the list from head to end
		for(Node currNode = head; currNode != null; currNode = currNode.getNext())
			if(currNode.getData() == x)
				return currNode;
		return null;
	}
	//Remove value x
	public Node removeNode(double x) {
		if(head == null)
			return null;
		Node currNode = head;
		//Remove head node if it matches x
		if(head.getData() == x) {
			this.head = head.getNext();
			return currNode;
		}
		//Traverse to find the node before the target (currNode.next matches x)
		for(; currNode.getNext() != null; currNode = currNode.getNext())
			if(currNode.getNext().getData() == x) {
				Node matchNode = currNode.getNext();
				//skip the target
				currNode.setNext(matchNode.getNext());
				return matchNode;
			}
		return null;
	}
	public void displayList() {
		Node currNode = head;
		if(currNode != null) {
			System.out.print(currNode.getData());
			for(currNode = currNode.getNext(); currNode != null; currNode = currNode.getNext()) {
				System.out.print(" -> " + currNode.getData());
			}
		}
		else
			System.out.print("Empty List!");
		System.out.println();
	}
	
	//Gets the last node of the linked list without removing it
	public Node getLast() {
		/*YOUR CODE HERE*/
        // Check if list is empty first
        if (this.isEmpty()) {
            return null;
        }
        // Traverse from head to the last node
        Node currNode = this.head;
        while (currNode.getNext() != null) {
            currNode = currNode.getNext();
        }
        // currNode is now the last node
        return currNode;
	}
	
	//Remove all nodes whose values are in the range [lower, upper] (inclusive)
	public int removeRange(int lower, int upper) {
		/*YOUR CODE HERE*/
        //no nodes to delete, return 0 immediately
        if (lower > upper) {
            return 0;
        }
        //track number of deleted nodes
        int deleteCount = 0;
        // Dummy node: handling head node deletion
        Node dummy = new Node(0.0);
        dummy.setNext(this.head);
        // currNode starts at dummy to check next node (target for deletion)
        Node currNode = dummy;

        // Traverse the list until no more nodes to check
        while (currNode.getNext() != null) {
            double nodeValue = currNode.getNext().getData();
            // Check if next node's value is in the target range
            if (nodeValue >= lower && nodeValue <= upper) {
                // Delete next node: skip it by pointing to its next
                currNode.setNext(currNode.getNext().getNext());
                deleteCount++; // Increment deletion counter
            } else {
                // Move to next node if no deletion (only when next node is safe)
                currNode = currNode.getNext();
            }
         }
        // Update head to dummy's next (handles case where original head was deleted)
        this.head = dummy.getNext();
        // Return total number of deleted nodes
        return deleteCount;
	}

	public static void main(String[] args) {
		/*YOUR CODE HERE*/
        // Test getLast()
        System.out.println("=== Testing getLast() ===");
        List list1 = new List();
        list1.insertNode(0, 1.0);
        list1.insertNode(1, 8.0);
        list1.insertNode(2, 2.0);
        list1.insertNode(3, 4.0);
        list1.insertNode(4, 3.0);
        System.out.print("List: ");
        list1.displayList();
        Node last = list1.getLast();
        System.out.println("Last node value: " + (last != null ? last.getData() : "null"));

        List emptyList = new List();
        System.out.print("Empty List: ");
        emptyList.displayList();
        System.out.println("Last node of empty list: " + (emptyList.getLast() != null ? emptyList.getLast().getData() : "null"));

        // Test removeRange()
        System.out.println("\n=== Testing removeRange() ===");
        List list2 = new List();
        list2.insertNode(0, 1.0);
        list2.insertNode(1, 8.0);
        list2.insertNode(2, 2.0);
        list2.insertNode(3, 4.0);
        list2.insertNode(4, 3.0);
        System.out.print("Original list: ");
        list2.displayList();
        int deleted = list2.removeRange(2, 3);
        System.out.print("After removeRange(2,3): ");
        list2.displayList();
        System.out.println("Deleted nodes: " + deleted);
	}
}