/*Add some comments by yourself.*/
package task2;

public class Stack {

	//Array to store stack elements
	private Double[] values;
	//Index of the top element (=-1 when empty)
	private int top;
	
	//Constructor: Initializes a stack with specified size
	public Stack(int size) {
		this.values = new Double[size];
		//Stack is empty initially
		top = -1;
	}
	
	//Checks if the stack is empty/full
	public boolean isEmpty() {
		return this.top < 0;
	}
	public boolean isFull() {
		return this.top == this.values.length - 1;
	}
	
	//Returns the top element without removing it
	public Double top() {
		if(top < 0)
			return null;
		return this.values[top];
	}
	//Push a new element onto the stack.
	public Double push(double x) {
		if(isFull())
			return null;
		this.values[++top] = Double.valueOf(x);
		return top();
	}
	//Removes and returns the top element.
	public Double pop() {
		if(top < 0)
			return null;
		return this.values[top --];
	}
	public void displayStack() {
		System.out.print("top -->");
		for(int i = this.top; i >= 0; i --)
			System.out.println("\t|\t " + String.format("%, .4f", this.values[i].doubleValue()) + "\t|");
		System.out.println("\t+-----------------------+");
	}
	
	public static double solvePost(String str) {
		/*YOUR CODE HERE*/
        // Split the input string into tokens (operands and operators)
        String[] tokens = str.split(" ");
        // Create a stack with capacity equal to the number of tokens (sufficient for all operands)
        Stack stack = new Stack(tokens.length);
        
        for (String token : tokens) {
            // Check if the token is an operator (+, -, *, /)
            if (token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/")) {
                // Pop two operands from the stack (note: order is important)
                double operand2 = stack.pop();
                double operand1 = stack.pop();
                double result = 0.0;
                
                // Perform the corresponding operation
                switch (token) {
                    case "+":
                        result = operand1 + operand2;
                        break;
                    case "-":
                        result = operand1 - operand2;
                        break;
                    case "*":
                        result = operand1 * operand2;
                        break;
                    case "/":
                    	// Assume valid input (no division by zero)
                        result = operand1 / operand2;
                        break;
                }
                // Push the result back to the stack
                stack.push(result);
            } else {
                // Token is an operand: parse to double and push to stack
                double operand = Double.parseDouble(token);
                stack.push(operand);
            }
        }
        // The remaining element in the stack is the final result
        return stack.pop();
	}
	public static void main(String[] args) {
		/*YOUR CODE HERE*/
        // Test case 1: "3 4 + 5 *" → (3+4)*5 = 35.0
        String expr1 = "3 4 + 5 *";
        System.out.println("Testing expression: " + expr1);
        System.out.println("Result: " + solvePost(expr1) + " (Expected: 35.0)");
        
        // Test case 2: "3.1" → 3.1
        String expr2 = "3.1";
        System.out.println("\nTesting expression: " + expr2);
        System.out.println("Result: " + solvePost(expr2) + " (Expected: 3.1)");
        
        // Test case 3: "3 2 /" → 3/2 = 1.5
        String expr3 = "3 2 /";
        System.out.println("\nTesting expression: " + expr3);
        System.out.println("Result: " + solvePost(expr3) + " (Expected: 1.5)");
        
        // Test case 4: "10 2 8 * + 3.5 -" → 10 + (2*8) - 3.5 = 22.5
        String expr4 = "10 2 8 * + 3.5 -";
        System.out.println("\nTesting expression: " + expr4);
        System.out.println("Result: " + solvePost(expr4) + " (Expected: 22.5)");
        
        // Test case 5: "2 3 1 * + 9 -" → 2 + (3*1) - 9 = -4.0
        String expr5 = "2 3 1 * + 9 -";
        System.out.println("\nTesting expression: " + expr5);
        System.out.println("Result: " + solvePost(expr5) + " (Expected: -4.0)");
        
        // Test case 6: "15 7 1 1 + - / 3 * 2 1 1 + + -" → 5.0
        String expr6 = "15 7 1 1 + - / 3 * 2 1 1 + + -";
        System.out.println("\nTesting expression: " + expr6);
        System.out.println("Result: " + solvePost(expr6) + " (Expected: 5.0)");
    }

}